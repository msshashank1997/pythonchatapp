const socket = io();

// Retrieve chat history on connection
socket.on('chat_history', function(history) {
    history.forEach(item => {
        if (item.type === 'message') {
            displayMessage(item.user, item.message);
        } else if (item.type === 'image') {
            displayImage(item.url, item.filename);
        }
    });
});

// Listen for new messages
socket.on('message', function(data) {
    displayMessage(data.user, data.message);
});

// Listen for new images
socket.on('image', function(data) {
    displayImage(data.url, data.filename);
});

// Send message function
function sendMessage() {
    const user = getUser();
    const message = document.getElementById("messageInput").value;
    if (!user || !message) return;

    socket.emit('message', { user: user, message: message });
    document.getElementById("messageInput").value = ''; // Clear message input
}

// Send image function
function sendImage() {
    const form = document.getElementById('imageForm');
    const formData = new FormData(form);

    fetch('/upload', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            console.log('Image uploaded and broadcasted');
        } else {
            console.error('Error:', data.error);
        }
    })
    .catch(error => {
        console.error('Error uploading image:', error);
    });
}

// Display message function
function displayMessage(user, message) {
    const messageElement = document.createElement("div");
    messageElement.classList.add("message");

    const messageContent = document.createElement("p");
    messageContent.innerHTML = `<strong>${user}</strong>: ${message}`;
    messageElement.appendChild(messageContent);

    document.getElementById("messagesList").appendChild(messageElement);
    document.getElementById("messagesList").scrollTop = document.getElementById("messagesList").scrollHeight;
}

// Display image function
function displayImage(url, filename) {
    const imageContainer = document.createElement('div');
    imageContainer.classList.add('image-container');

    const img = document.createElement('img');
    img.src = url;
    img.style.width = '4em';
    img.style.height = '4em';
    img.classList.add('chat-image');

    const downloadButton = document.createElement('a');
    downloadButton.href = `/download/${filename}`;
    downloadButton.classList.add('download-button');
    downloadButton.download = filename;

    const downloadIcon = document.createElement('i');
    downloadIcon.classList.add('fas', 'fa-download');
    downloadButton.appendChild(downloadIcon);

    imageContainer.appendChild(img);
    imageContainer.appendChild(downloadButton);
    document.getElementById('messagesList').appendChild(imageContainer);
    document.getElementById("messagesList").scrollTop = document.getElementById("messagesList").scrollHeight;
}

// Save and retrieve user data from localStorage
function getUser() {
    let user = localStorage.getItem('username');
    if (!user) {
        user = prompt("Enter your name:");
        localStorage.setItem('username', user);
    }
    document.getElementById("userInput").value = user;
    return user;
}

// Load user name from local storage when the page loads
window.onload = function() {
    getUser();
}
