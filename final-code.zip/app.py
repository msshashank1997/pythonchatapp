from flask import Flask, render_template, request, jsonify, url_for, send_from_directory
from flask_socketio import SocketIO, emit
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['MAX_CONTENT_LENGTH'] = 5 * 1024 * 1024  # 5 MB max file size
socketio = SocketIO(app)

# Store messages for session persistence
chat_history = []

if not os.path.exists(app.config['UPLOAD_FOLDER']):
    os.makedirs(app.config['UPLOAD_FOLDER'])

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'success': False, 'error': 'No file part'})

    file = request.files['file']
    if file.filename == '':
        return jsonify({'success': False, 'error': 'No selected file'})

    filename = secure_filename(file.filename)
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(filepath)

    image_url = url_for('static', filename=f'uploads/{filename}')
    socketio.emit('image', {'url': image_url, 'filename': filename})
    chat_history.append({'type': 'image', 'url': image_url, 'filename': filename})
    return jsonify({'success': True, 'url': image_url})

@app.route('/download/<filename>')
def download_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename, as_attachment=True)

@socketio.on('connect')
def handle_connect():
    # Send chat history to the newly connected client
    emit('chat_history', chat_history)

@socketio.on('message')
def handle_message(data):
    # Broadcast message and save to chat history
    chat_message = {'type': 'message', 'user': data['user'], 'message': data['message']}
    chat_history.append(chat_message)
    emit('message', chat_message, broadcast=True)

if __name__ == '__main__':
    socketio.run(app, debug=True)
