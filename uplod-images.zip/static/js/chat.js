const socket = io();

socket.on('message', function(data) {
    const messageElement = document.createElement("div");
    messageElement.classList.add("message");

    const messageContent = document.createElement("p");
    messageContent.innerHTML = `<strong>${data.user}</strong>: ${data.message} <span class="timestamp">${data.time}</span>`;

    messageElement.appendChild(messageContent);
    document.getElementById("messagesList").appendChild(messageElement);

    // Auto-scroll to the bottom of the chat
    document.getElementById("messagesList").scrollTop = document.getElementById("messagesList").scrollHeight;
});

socket.on('image', function(data) {
    const imageContainer = document.createElement('div');
    imageContainer.classList.add('image-container');

    const img = document.createElement('img');
    img.src = data.url;
    img.style.width = '4em';
    img.style.height = '4em';  // Display image at 4x4 size without changing pixel data
    img.classList.add('chat-image');  // CSS class for styling if needed

    const downloadButton = document.createElement('a');
    downloadButton.href = `/download/${data.filename}`;
    downloadButton.classList.add('download-button');
    downloadButton.download = data.filename;

    const downloadIcon = document.createElement('i');
    downloadIcon.classList.add('fas', 'fa-download');  // Font Awesome download icon classes
    downloadButton.appendChild(downloadIcon);

    imageContainer.appendChild(img);
    imageContainer.appendChild(downloadButton);
    document.getElementById('messagesList').appendChild(imageContainer);

    // Auto-scroll to the bottom of the chat
    document.getElementById("messagesList").scrollTop = document.getElementById("messagesList").scrollHeight;
});

function sendMessage() {
    const user = document.getElementById("userInput").value;
    const message = document.getElementById("messageInput").value;
    if (!user || !message) return;

    socket.emit('message', {user: user, message: message});
    document.getElementById("messageInput").value = '';
}

function sendImage() {
    const form = document.getElementById('imageForm');
    const formData = new FormData(form);

    fetch('/upload', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            console.log('Image uploaded and broadcasted');
        } else {
            console.error('Error:', data.error);
        }
    })
    .catch(error => {
        console.error('Error uploading image:', error);
    });
}
