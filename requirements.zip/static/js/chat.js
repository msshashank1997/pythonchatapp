const socket = io();

socket.on('message', function(data) {
    const messageElement = document.createElement("div");
    messageElement.className = 'message';
    
    // Align with the HTML template's message format
    if (data.sessionId === socket.id) {
        messageElement.style.alignSelf = 'flex-end';
        messageElement.style.backgroundColor = '#34b7f1';
        messageElement.style.color = 'white';
    }
    
    messageElement.textContent = `${data.username}: ${data.message}`;
    document.getElementById("messages").appendChild(messageElement);

    // Auto-scroll to the bottom of the chat
    const chatWindow = document.getElementById("chat-window");
    chatWindow.scrollTop = chatWindow.scrollHeight;
});

function sendMessage(event) {
    event.preventDefault();
    
    const messageInput = document.getElementById('message-input');
    if (!messageInput) {
        console.error('Message input element not found');
        return;
    }

    const message = messageInput.value.trim();
    if (!message) return;

    // Use the existing socket instance
    socket.emit('message', {
        message: message,
        username: window.username || 'Anonymous',
        sessionId: socket.id
    });
    
    messageInput.value = '';
}

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('message-form');
    if (form) {
        form.addEventListener('submit', sendMessage);
    }
});